<?php
$jenis = $_POST['jenis'];
if ($jenis == "pilih") {
?>
<option>Pilih dulu Jenisnya</option>
<?php
} elseif ($jenis == "1") {
?>
<option>-- Pilih Layanan --</option>
<option value="1">Instagram Likes S1 [Min = 100] [Max = 4k] (Rp. 2.000/1000 Likes)</option>
<option value="2">Instagram Likes S2 [Min = 100] [Max = 15k] (Rp. 2.500/1000 Likes)</option>
<option value="3">Instagram Likes S3 [Min = 100] [Max = 8k] (Rp. 3.000/1000 Likes)</option>
<option value="4">Instagram Likes S4 [Min = 50] [Max = 25k] (Rp. 5.000/1000 Likes)</option>
<option value="5">Instagram Followers S1 [Min = 200] [Max = 15k] (Rp. 11.000/1000 Followers)</option>
<option value="6">Instagram Views S1 [Min = 20] [Max = 999k] (Rp. 3.000/1000 Views)</option>
<option value="7">Instagram Views S2 (INSTANT - SUPER FAST) [Min = 20] [Max = 999k] (Rp. 5.000/1000 Views)</option>
<option value="8">Instagram Story Views UNLIMITED (USERNAME ONLY) [Min = 1k] [Max = 1M] (Rp. 27.000/1000 Views)</option>
<option value="9">Instagram Video Live Likes (INSTANT) [Min = 200] [Max = 10k] (Rp. 11.000/1000 Likes)</option>
<option value="10">Instagram ALBUM Likes (REAL - INSTANT) [Min = 100] [Max = 4k] (Rp. 3.000/1000 Likes)</option>
<option value="11">Instagram Followers HQ S2 [Min = 100] [Max = 20k] (Rp. 33.000/1000 Followers)</option>
<option value="12">Instagram Followers S3 (HQ - INSTANT - FAST - NOT GUARANTEED) [Min = 200] [Max = 15k] (Rp. 27.000/1000 Followers)</option>
<option value="13">Instagram Followers S4 (HQ - 30 Days Refill) [Min = 200] [Max = 10k] (Rp. 33.000/1000 Followers)</option>
<option value="30">Instagram Followers Aktif Indonesia (Manual - FAST) [Min = 100] [Max = 3k] (Rp. 55.000/1000 Followers)</option>
<option value="31">Instagram Followers (20K] [USA - INSTANT] [NON DROP - 60 DAYS REFILL] (Rp. 45.000/1000 Followers)</option>
<?php 
} elseif ($jenis == "2") {
?>
<option>-- Pilih Layanan --</option>
<option value="14">Youtube Views (Multiple Of 1000 - REAL - DESKTOP - 60 Days Warranty) [Min = 1k] [Max = 1M] (Rp. 15.000/1000 Views)</option>
<option value="15">Youtube Subscribers (INSTANT - 120 Days GUARANTEE) [Min = 100] [Max = 25k] (Rp. 370.000/1000 Subscribers)</option>
<option value="23">Youtube Likes (INSTANT - SUPER FAST) [Min = 50] [Max = 20k] (Rp. 80.000/1000 Likes)</option>
<option value="24">Youtube Dislikes (INSTANT - SUPER FAST) [Min = 50] [Max = 20k] (Rp. 80.000/1000 Dislikes)</option>
<option value="25">Youtube Shares S1 (INSTANT) [Min = 100] [Max = 22k] (Rp. 55.000/1000 Shares)</option>
<?php
} elseif ($jenis == "3") {
?>
<option>-- Pilih Layanan --</option>
<option value="16">Facebook Page Likes (REAL - GUARANTEED - 12 HOURS START) [Min = 100] [Max = 15k] (Rp. 27.000/1000 Likes)</option>
<option value="17">Facebook Page Likes (REAL - NON DROP - 60 Days AUTO REFILL - INSTANT - SUPER FAST) [Min = 100] [Max = 180k] (Rp. 40.000/1000 Likes)</option>
<option value="18">Facebook Followers (INSTANT - 1k/Day - 60 Days Refill) [Min = 100] [Max = 5k] (Rp. 50.000/1000 Followers)</option>
<?php 
} elseif ($jenis == "4") {
?>
<option>-- Pilih Layanan --</option>
<option value="19">Twitter Followers (USERNAME ONLY - EGGS - INSTANT) [Min = 100] [Max = 5M] (Rp. 12.000/1000 Followers)</option>
<option value="20">Twitter Followers (USERNAME ONLY - EGGS - REFILL - INSTANT) [Min = 100] [Max = 300k] (Rp. 20.000/1000 Followers)</option>
<option value="21">Twitter Likes/Favorites (INSTANT) [Min = 100] [Max = 500k] (Rp. 9.000/1000 Likes)</option>
<option value="22">Twitter Retweets (INSTANT) [Min = 100] [Max = 500k] (Rp. 9.000/1000 Retweets)</option>
<?php
} elseif ($jenis == "5") {
?>
<option>-- Pilih Layanan --</option>
<option value="26">Vine Followers [Min = 100] [Max = 50k] (Rp. 23.000/1.000 Followers)</option>
<option value="27">Vine Likes [Min = 100] [Max = 50k] (Rp. 23.000/1.000 Likes)</option>
<?php
}
?>