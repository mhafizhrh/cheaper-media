<?php
	$layanan = $_POST['layanan'];
	if ($layanan == 1) { // Instagram Service
		echo "<input value='2' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 2000<br>
	Minimal Order : 100<br>
	Maksimal Order : 4000
</div>
<?php
	} else if ($layanan == 2) {
		echo "<input value='2.5' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 2500<br>
	Minimal Order : 100<br>
	Maksimal Order : 15000
</div>
<?php
	} else if ($layanan == 3) {
		echo "<input value='3' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 3000<br>
	Minimal Order : 100<br>
	Maksimal Order : 8000
</div>
<?php
	} else if ($layanan == 4) {
		echo "<input value='5' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 5000<br>
	Minimal Order : 50<br>
	Maksimal Order : 25000
</div>
<?php
	} else if ($layanan == 5) {
		echo "<input value='11' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 11000<br>
	Minimal Order : 200<br>
	Maksimal Order : 15000
</div>
<?php
	} else if ($layanan == 6) {
		echo "<input value='3' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 3000<br>
	Minimal Order : 20<br>
	Maksimal Order : 999000
</div>
<?php
	} else if ($layanan == 7) {
		echo "<input value='5' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 5000<br>
	Minimal Order : 20<br>
	Maksimal Order : 999000
</div>
<?php
	} else if ($layanan == 8) {
		echo "<input value='27' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 27000<br>
	Minimal Order : 1000<br>
	Maksimal Order : 1000000
</div>
<?php
	} else if ($layanan == 9) {
		echo "<input value='11' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 11000<br>
	Minimal Order : 200<br>
	Maksimal Order : 10000
</div>
<?php
	} else if ($layanan == 10) {
		echo "<input value='3' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 3000<br>
	Minimal Order : 100<br>
	Maksimal Order : 4000
</div>
<?php
	} else if ($layanan == 11) {
		echo "<input value='33' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 33000<br>
	Minimal Order : 100<br>
	Maksimal Order : 20000
</div>
<?php
	} else if ($layanan == 12) {
		echo "<input value='27' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 27000<br>
	Minimal Order : 100<br>
	Maksimal Order : 15000
</div>
<?php
	} else if ($layanan == 13) {
		echo "<input value='33' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 33000<br>
	Minimal Order : 200<br>
	Maksimal Order : 10000
</div>
<?php
	} else if ($layanan == 30) { 
		echo "<input value='55' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 55000<br>
	Minimal Order : 100<br>
	Maksimal Order : 3000
</div>
<?php
	} else if ($layanan == 31) {
		echo "<input value='45' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 45000<br>
	Minimal Order : 20<br>
	Maksimal Order : 20000
</div>
<?php
	} else if ($layanan == 14) { // Youtube
		echo "<input value='15' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 15000<br>
	Minimal Order : 1000<br>
	Maksimal Order : 1000000
</div>
<?php
	} else if ($layanan == 15) {
		echo "<input value='370' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 370000<br>
	Minimal Order : 100<br>
	Maksimal Order : 25000
</div>
<?php
	} else if ($layanan == 23) {
		echo "<input value='80' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 80000<br>
	Minimal Order : 50<br>
	Maksimal Order : 20000
</div>
<?php
	} else if ($layanan == 24) {
		echo "<input value='80' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 80000<br>
	Minimal Order : 50<br>
	Maksimal Order : 20000
</div>
<?php
	} else if ($layanan == 25) {
		echo "<input value='55' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 55000<br>
	Minimal Order : 100<br>
	Maksimal Order : 22000
</div>
<?php
	} else if ($layanan == 16) { // Facebook
		echo "<input value='27' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 27000<br>
	Minimal Order : 100<br>
	Maksimal Order : 15000
</div>
<?php
	} else if ($layanan == 17) {
		echo "<input value='40' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 40000<br>
	Minimal Order : 100<br>
	Maksimal Order : 180000
</div>
<?php
	} else if ($layanan == 18) {
		echo "<input value='50' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 50000<br>
	Minimal Order : 100<br>
	Maksimal Order : 5000
</div>
<?php
	} else if ($layanan == 19) { // Twitter
		echo "<input value='12' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 12000<br>
	Minimal Order : 100<br>
	Maksimal Order : 5000000
</div>
<?php
	} else if ($layanan == 20) {
		echo "<input value='20' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 20000<br>
	Minimal Order : 100<br>
	Maksimal Order : 300000
</div>
<?php
	} else if ($layanan == 21) {
		echo "<input value='9' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 9000<br>
	Minimal Order : 100<br>
	Maksimal Order : 500000
</div>
<?php
	} else if ($layanan == 22) {
		echo "<input value='9' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 9000<br>
	Minimal Order : 100<br>
	Maksimal Order : 500000
</div>
<?php
	} else if ($layanan == 26) {
		echo "<input value='23' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 23000<br>
	Minimal Order : 100<br>
	Maksimal Order : 50000
</div>
<?php
	} else if ($layanan == 27) {
		echo "<input value='23' id='eceran' hidden>";
?>
<label>Keterangan :</label>
<div class="alert alert-info">
	Harga/1000 :  Rp. 23000<br>
	Minimal Order : 100<br>
	Maksimal Order : 50000
</div>
<?php
	} else {
		false;
	}
?>
