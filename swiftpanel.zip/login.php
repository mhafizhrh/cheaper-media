
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="assets/images/favicon.png">

    <title>Swift Panel</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="assets/css/offcanvas.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
  </head>

  <body>
    <nav class="navbar navbar-fixed-top navbar-default">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Swift Panel</a>
        </div>
        <div id="navbar" class="collapse navbar-collapse navbar-right">
          <ul class="nav navbar-nav">
            <li class="active"><a href="login.php">Masuk</a></li>
            <li><a href="daftar-harga.php">Daftar Harga</a></li>
          </ul>
        </div><!-- /.nav-collapse -->
      </div><!-- /.container -->
    </nav><!-- /.navbar -->

    <div class="container">

      <div class="row">
        <div class="col-md-5 col-md-offset-3">
<?php
session_start();
if (isset($_SESSION['username'])) {
    header('location:index.php');
}
require_once 'koneksi.php';
if (isset($_POST['masuk'])) {
  $username = $_POST['username'];
  $password = $_POST['password'];
  $ip       = $_SERVER['REMOTE_ADDR'];
  $query    = mysql_query("SELECT * FROM users WHERE username = '$username'");
    $rows     = mysql_num_rows($query);
    $array    = mysql_fetch_array($query);
    if (!$username || !$password) {
        echo "<div class='alert alert-danger text-center'>Tolong lengkapi data</div>";
    } else {
        if ($rows == 0) {
            echo "<div class='alert alert-danger text-center'>Username tidak ada</div>";
        } elseif ($password <> $array['password']) {
            echo "<div class='alert alert-danger text-center'>Password salah</div>";
        } else {
            $_SESSION['username'] = $array['username'];
            mysql_query("UPDATE users SET ip = '$ip' WHERE username = '$username'");
            header('location:index.php');
        }
    }
}
?>
          <div class="panel panel-info">
            <div class="panel-heading text-center">
              Masuk dengan akun Swift Panel
            </div>
            <div class="panel-body">
              <form method="post">
                <div class="form-group">
                  <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-user"></i></span>
                    <input type="text" name="username" class="form-control" placeholder="Username anda">
                  </div>
                </div>
                <div class="form-group">
                  <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                    <input type="password" name="password" class="form-control" placeholder="Password anda">
                  </div>
                </div>
                <div class="form-group">
                  <button type="submit" class="btn btn-primary btn-block" name="masuk">Masuk</button>
                </div>
                <div class="form-group">
                  Belum punya akun? <a href="https://facebook.com/hafizh.rh">Daftar</a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

    </div><!--/.container-->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
    <script src="offcanvas.js"></script>
  </body>
</html>
