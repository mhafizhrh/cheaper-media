<?php
session_start();
if (!isset($_SESSION['username'])) {
  header('location:login.php');
} else {
  $username = $_SESSION['username'];
}
require_once 'koneksi.php';
// Select From table users
$select = mysql_query("SELECT * FROM users WHERE username = '$username'");
$data = mysql_fetch_array($select);

// Data Users
$nama = $data['nama'];
$password = $data['password'];
$email = $data['email'];
$saldo = $data['saldo'];
$ip = $data['ip'];
header('location:order.php');
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="assets/images/cm-icon.png">

    <title>Cheaper Media</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="assets/css/offcanvas.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
  </head>

  <body>
    <nav class="navbar navbar-fixed-top navbar-default">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Cheaper Media</a>
        </div>
        <div id="navbar" class="collapse navbar-collapse navbar-right">
          <ul class="nav navbar-nav">
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="order.php">Pembelian Baru</a></li>
            <li><a href="riwayat-order.php">Riwayat Pembelian</a></li>
            <li class="dropdown">
              <a href="#" data-toggle="dropdown">Saldo <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="#" data-toggle="modal" data-target="#saldo">Cek Saldo</a></li>
                <li><a href="saldo.php">Beli</a></li>
                <li><a href="riwayat-saldo.php">Riwayat</a></li>
              </ul>
            </li>
            <li>
              <a href="#" data-toggle="modal" data-target="#modal"><i class="fa fa-bars"></i></a>
            </li>
          </ul>
        </div><!-- /.nav-collapse -->
      </div><!-- /.container -->
    </nav><!-- /.navbar -->


    <!--Modal-->
    <div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" id="saldo">
      <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="btn btn-primary btn-block" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></button>
          </div>
          <div class="modal-body">
            <div class="input-group">
              <span class="input-group-addon">Rp.</span>
              <input type="number" class="form-control" value="<?=$saldo?>" readonly>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" id="modal">
      <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="btn btn-primary btn-block" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></button>
          </div>
          <div class="modal-body">
            <a href="profil.php" class="btn btn-default btn-block"><i class="fa fa-user"></i> Profil</a>
            <a href="pengaturan.php" class="btn btn-default btn-block"><i class="fa fa-cog"></i> Pengaturan</a>
            <a href="bantuan.php" class="btn btn-default btn-block"><i class="fa fa-support"></i> Bantuan</a>
            <a href="keluar.php" class="btn btn-default btn-block"><i class="fa fa-power-off"></i> Keluar</a>
          </div>
        </div>
      </div>
    </div>
    <!--/Modal-->


    <div class="container">

      <div class="row">
        <div class="col-md-8 col-md-offset-2">
          <h2 class="text-center">Selamat Datang, <?=$nama?></h2>
          <div class="panel panel-info">
            <div class="panel-heading text-center">
              Informasi
            </div>
            <div class="panel-body">
              <div class="alert alert-info">
                <i class="fa fa-info-circle"></i>
                Marhaban ya Ramadhan, Selamat menjalankan Ibadah Puasa bagi yang menjalankannya.
              </div>
              <div class="alert alert-info">
                <i class="fa fa-info-circle"></i>
                Good Luck, Happy Shopping.
              </div>
            </div>
          </div>
        </div>
      </div>

      <hr>

      <footer>
        <p class="text-muted"><a href="https://www.facebook.com/hafizh.rh">Hafizh Rahman</a> &copy; 2017 Cheaper Media.</p>
      </footer>

    </div><!--/.container-->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
    <script src="offcanvas.js"></script>
  </body>
</html>
